package person;

/**
 * This class store objects from class Person
 *
 */
public class Repository {
    /**
     * Array for Person.index
     */
    private Person[] personStorage;
    
    
    /**
     * Getter of length of repository
     * @return length of repository
     */
    public final Integer getLengthOfPersonStorage() {
		return personStorage.length;
	}


	/**
     * Repository constructor
     */
    public Repository() {
        personStorage = new Person[0];
    }

    /**
   	 * Getter of object Person
     * @param index of array
     * @return appropriate object or nothing
     */
    public final Person getPerson(final int index) {
        if (index + 1 <= personStorage.length) {
            return personStorage[index];
        } else {
            return null;
        }
    }

    /**
     * Getter of object Person
     * @param Person id
     * @return appropriate object or noting
     */
    public final Person getPersonById(final int id) {
        for (Person i : personStorage) {
            if (i.getId() == id) {
                return i;
            }
        }
        return null;
    }
    
    /**
     * Method which add object Person
     * @param Person
     */
    public final void add(final Person person) {
        Person[] localPersonStorage = new Person[personStorage.length + 1];

        System.arraycopy(personStorage, 0, localPersonStorage, 0, personStorage.length);

        localPersonStorage[localPersonStorage.length - 1] = person;
        personStorage = new Person[localPersonStorage.length];

        System.arraycopy(localPersonStorage, 0, personStorage, 0, localPersonStorage.length);
    }
    

    /**
     * Method which delete element of array(repository)
     * @param index of array
     */
    public final void delete(final int index) {
        Repository localRepository = new Repository();

        for (int i = 0; i < personStorage.length; i++) {
            if (i != index) {
                localRepository.add(personStorage[i]);
            }
        }

        Person[] localPersonStorage =
                new Person[localRepository.personStorage.length];

        System.arraycopy(localRepository.personStorage, 0, localPersonStorage, 0, localRepository.personStorage.length);
        personStorage = new Person[localPersonStorage.length];
        System.arraycopy(localPersonStorage, 0, personStorage, 0,localPersonStorage.length);
    }

    /**
     * Method which delete element of array(repository)
     * @param appropirate person 
     */
    public final void delete(final Person person) {
        Repository localRepository = new Repository();

        for (Person i : personStorage) {
            if (person.getId() != i.getId()) {
                localRepository.add(i);
            }
        }

        Person[] localPersonStorage = new Person[localRepository.personStorage.length];

        System.arraycopy(localRepository.personStorage, 0, localPersonStorage, 0, localRepository.personStorage.length);

        personStorage = new Person[localPersonStorage.length];

        System.arraycopy(localPersonStorage, 0, personStorage, 0, localPersonStorage.length);
    }
    /**
     * toString override for array of objects Person
     * @return s
     */
    @Override
    public final String toString() {
        StringBuilder buf = new StringBuilder("");
        for (Person i : personStorage) {
            buf.append(i.toString());
            buf.append("\n");
        }
        return buf.toString();
    }

}
