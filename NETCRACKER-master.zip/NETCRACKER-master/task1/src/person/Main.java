package person;

import org.joda.time.DateTime;

public class Main {
	public static void main(final String[] args) {
        Repository rep = new Repository();
        Person per1 = new Person("Volodya", "Stariy", DateTime.parse("1960-10-27T10:11:12.123"));
        Person per2 = new Person("John", "Travolta", DateTime.parse("1954-02-18T10:11:12.123"));
        System.out.println(per1.toString() + " " + per1.getAge().toString() + " " + per1.getIndex());
        System.out.println(per2.toString() + " " + per2.getAge().toString() + " " + per2.getIndex());
        rep.add(per1);
        rep.add(per2);
        rep.delete(1);
        System.out.println(rep.toString() + rep.getLengthOfPersonStorage());
    }

}
