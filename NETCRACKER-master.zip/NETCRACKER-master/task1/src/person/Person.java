package person;
//import java.util.*;
import org.joda.time.DateTime;


/**
 *This class describes Person
 */
public class Person {
	
    /**
     * Index for Repository.
     */
	private static int index = 0;
	
	/**
	 * field for id
	 */
	private Integer id;

	/**
	 * field for surname
	 */
	private String surname;
	
	/**
	 * field for name
	 */
	private String name;
	
	/**
	 * field for birthYear
	 */
	private Integer birthYear;
	
	/**
	 * field for birthMonth
	 */
	private Integer birthMonth;
	
	/**
	 * field for birthDay
	 */
	private Integer birthDay;
	
    /** 
     * field for gender
     */
	private String gender;
	
	
	/**
	 * Person Constructor 
	 * @param name 
	 * @param surname
	 * @param birthDate
	 */
	public Person(final String name, final String surname, final DateTime birthDate) {
		super();
		this.surname = surname;
		this.name = name;
		this.birthYear = birthDate.getYear();
	    this.birthMonth = birthDate.getMonthOfYear();
	    this.birthDay = birthDate.getDayOfMonth();
		id = index;
		index++;
	}
	
	
	/**
	 * Getter of age
	 * @return age
	 */
    public final Integer getAge() {
    	if(this.birthMonth < DateTime.now().getMonthOfYear())
    		return DateTime.now().getYear() - this.birthYear;
    	else if(this.birthMonth == DateTime.now().getMonthOfYear())
    		if (this.birthDay < DateTime.now().getDayOfMonth())
    			return DateTime.now().getYear() - this.birthYear;
    		else 
    			return DateTime.now().getYear() - this.birthYear + 1;
    	else
    		return DateTime.now().getYear() - this.birthYear + 1;
    			
    }
    
    
	/**
	 * Getter of birthYear
	 * @return birthYear
	 */
	public final int getIndex() {
		return index;
	}
	
		
	

	/**
	 * Getter of birthYear
	 * @return birthYear
	 */
	public final Integer getBirthYear() {
		return birthYear;
	}
	
	/**
	 * Setter of birthYear
	 * @return new birthYear
	 */
	public final void setBirthYear(final Integer birthYear) {
		this.birthYear = birthYear;
	}
	
	
	/**
	 * Getter of birthMonth
	 * @return birthMonth
	 */
	public final Integer getBirthMonth() {
		return birthMonth;
	}
	
	/**
	 * Setter of birthMonth
	 * @return new birthMonth
	 */
	public final void setBirthMonth(final Integer birthMonth) {
		this.birthMonth = birthMonth;
	}
	
	
	/**
	 * Getter of birthDay
	 * @return birthDay
	 */
	public final Integer getBirthDay() {
		return birthDay;
	}
	
	/**
	 * Setter of birthDay
	 * @return new birthDay
	 */
	public final void setBirthDay(final Integer birthDay) {
		this.birthDay = birthDay;
	}
	
	
	/**
	 * Getter of id
	 * @return id
	 */
	public final Integer getId(){
		return id;
        }
	
	/**
	 * Setter of id
	 * @return new id
	 */
	public final void setId(Integer id){
		this.id = id;
	    }
	
	
	/**
	 * Getter of surname
	 * @return surname
	 */
	public final String getSurname(){
	    return surname;
	    }
	
	/**
	 * Setter of surname
	 * @return new surname
	 */
	public final void setSurname(String surname){
	    this.surname = surname;
	    }
	
	
	/**
	 * Getter of name
	 * @return name
	 */
	public final String getName() {
	    return name;
	    }
	
	/**
	 * Setter of name
	 * @return new name
	 */
	public final void setName(String name){
	    this.name = name;
	    }
	
	
	/**
	 * Getter of gender
	 * @return gender
	 */
	public final String getGender() {
		return gender;
		}
	
	/**
	 * Setter of gender
	 * @return new gender
	 */
	public final void setGender(String gender) {
    if ((this.gender == "M") || (this.gender == "m") || (this.gender == "Male") || (this.gender == "male")) 
    	this.gender = "Male";
    else if ((this.gender == "F") || (this.gender == "f") || (this.gender == "Female") || (this.gender == "female")) 
    	this.gender = "Female";
	}
	

	@Override
	/**
	 * toString override for Person
	 * @return name and surname 
	 */
	public final String toString() {
		return this.name + " " + this.surname;
    }
   
}
